#Change logs

**version 1.1.0, February 12, 2020**

- [Improvement] Add expired license checking version 2
