# pda-languages
Languages for Prevent Direct Access WordPress plugin

+ Install the software https://poedit.net/
+ In order to create a new translation: open the prevent-direct-access-gold.pot file
+ In order to edit a existing translation: edit the prevent-direct-acess-gold-<language>.pot file.
