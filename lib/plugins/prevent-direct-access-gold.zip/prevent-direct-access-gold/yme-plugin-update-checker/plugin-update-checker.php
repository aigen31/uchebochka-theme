<?php
/**
 * Plugin Update Checker Library 4.8
 * http://w-shadow.com/
 *
 * Copyright 2019 Janis Elsts
 * Released under the MIT license. See license.txt for details.
 */

require dirname(__FILE__) . '/load-v4p8.php';