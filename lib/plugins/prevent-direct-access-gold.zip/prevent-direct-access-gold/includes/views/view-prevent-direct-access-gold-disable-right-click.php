<tr>
	<?php if ( $setting->getSettings(PDA_v3_Constants::DISABLE_RIGHT_CLICK ) ) { ?>
		<td>
			<label class="pda_switch" for="disable_right_click">
				<input type="checkbox" id="disable_right_click" name="disable_right_click" checked/>
				<span class="pda-slider round"></span>
			</label>
			<div class="pda_error" id="pda_l_error"></div>
		</td>
	<?php } else { ?>
		<td>
			<label class="pda_switch" for="disable_right_click">
				<input type="checkbox" id="disable_right_click" name="disable_right_click"/>
				<span class="pda-slider round"></span>
			</label>
			<div class="pda_error" id="pda_l_error"/>
		</td>
	<?php } ?>
	<td>
		<p>
			<label><?php echo esc_html__( 'Disable Right Click', 'prevent-direct-access-gold' ) ?></label>
			<?php echo esc_html__( 'Enable this option to disable right-click on all your web pages', 'prevent-direct-access-gold' ) ?>
		</p>
	</td>
</tr>
