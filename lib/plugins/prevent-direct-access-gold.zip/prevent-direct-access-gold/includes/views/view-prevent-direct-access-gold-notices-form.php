<div class="main_container">
	<div class="pda_sub_div">
		<h2>Warning</h2>
		<p>Please update <a href="plugins.php">Password Protect WordPress Pro</a> to version 1.1.3 in order to integrate with <a target="_blank" rel="noopener noreferrer" href="https://passwordprotectwp.com/docs/prevent-direct-access-gold-integration-logic/">Prevent Direct Access Gold</a> properly.</p>
	</div>
</div>
