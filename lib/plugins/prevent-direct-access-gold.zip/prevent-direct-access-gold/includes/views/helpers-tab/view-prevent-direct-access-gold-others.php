<p>
	Please make sure you've <a href="https://preventdirectaccess.com/docs/pda-rewrite-rules/#rewrite-rules" target="_blank" rel="noopener noreferrer">implemented our rewrite rules</a> according to your server type for our plugin to work properly.
</p>

